## Additional Resources

For a detailed walkthrough of how this project was built and the challenges we faced, check out our Medium blog post: [https://medium.com/@suryask4530/setup-ci-cd-pipeline-using-github-actions-for-reactjs-application-hosted-on-aws-ec2-8aefd114fb21]

In this blog post, you will find:
- A step-by-step guide to the development process


We hope you find it helpful! 
